<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Database\Eloquent\Builder;

use App\Models\Store;
use App\Models\PublicStore;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Product;
use App\Models\Customer;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /*
    |--------------------------------------------------------------------------
    | Mass assignment
    |--------------------------------------------------------------------------
    */
    protected $fillable = [
        'name',
        'email',
        'role',
        'password',
        'phone',
        'avatar_path',
        'status',
        'address',
    ];

    /*
    |--------------------------------------------------------------------------
    | Hidden
    |--------------------------------------------------------------------------
    */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /*
    |--------------------------------------------------------------------------
    | Casts
    |--------------------------------------------------------------------------
    */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    /*
    |--------------------------------------------------------------------------
    | API query rules (seguras)
    |--------------------------------------------------------------------------
    */
    protected $allowIncluded = [
        'store',
        'publicStore',
        'carts',
        'orders',
    ];

    protected $allowSort = [
        'name',
        'email',
        'status',
        'created_at',
    ];

    protected $allowFilter = [
        'name',
        'email',
        'status',
    ];

    /*
    |--------------------------------------------------------------------------
    | Relaciones
    |--------------------------------------------------------------------------
    */
    public function store()
    {
        return $this->hasOne(Store::class);
    }

    public function publicStore()
    {
        return $this->hasOne(PublicStore::class);
    }

    public function carts()
    {
        return $this->hasMany(Cart::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function products()
    {
        return $this->hasManyThrough(
            Product::class,
            Store::class,
            'user_id',   // FK en stores
            'store_id',  // FK en products
            'id',
            'id'
        );
    }

    public function customerVisits()
    {
        return $this->hasMany(Customer::class);
    }

    /*
    |--------------------------------------------------------------------------
    | Accessors
    |--------------------------------------------------------------------------
    */
    public function getFormattedNameAttribute(): string
    {
        return ucwords(strtolower($this->name));
    }

    public function getInitialsAttribute(): string
    {
        return collect(explode(' ', trim($this->name)))
            ->map(fn ($part) => strtoupper(substr($part, 0, 1)))
            ->implode('');
    }

    /*
    |--------------------------------------------------------------------------
    | Roles helpers (Spatie)
    |--------------------------------------------------------------------------
    */
    public function esComerciante(): bool
    {
        return $this->roleKey() === 'merchant';
    }

    public function esCliente(): bool
    {
        return $this->roleKey() === 'client';
    }

    public function isMerchant(): bool
    {
        return $this->esComerciante();
    }

    public function isClient(): bool
    {
        return $this->esCliente();
    }

    public function roleKey(): string
    {
        $role = strtolower((string) $this->role);
        if ($role === 'comerciante') {
            return 'merchant';
        }

        if ($role === 'cliente') {
            return 'client';
        }

        if (in_array($role, ['merchant', 'admin'], true)) {
            return $role;
        }

        $legacyRole = '';
        if (!empty($this->role_id)) {
            $legacyRole = strtolower((string) (Role::query()->where('id', $this->role_id)->value('name') ?? ''));
        }

        $hasStore = $this->relationLoaded('store')
            ? $this->store !== null
            : $this->store()->exists();

        $hasMerchantRole = $this->hasRole(['comerciante', 'merchant']);

        if ($role === 'client') {
            if ($hasMerchantRole || in_array($legacyRole, ['comerciante', 'merchant', 'seller'], true) || $hasStore) {
                return 'merchant';
            }

            return 'client';
        }

        if ($this->hasRole(['admin'])) {
            return 'admin';
        }

        if ($hasMerchantRole) {
            return 'merchant';
        }

        if ($this->hasRole(['cliente', 'client'])) {
            return 'client';
        }

        if (in_array($legacyRole, ['comerciante', 'merchant', 'seller'], true)) {
            return 'merchant';
        }
        if (in_array($legacyRole, ['cliente', 'client', 'buyer'], true)) {
            return 'client';
        }

        // Legacy fallback: if the user already owns a store, treat as merchant.
        if ($hasStore) {
            return 'merchant';
        }

        return 'client';
    }

    /*
    |--------------------------------------------------------------------------
    | Store helpers
    |--------------------------------------------------------------------------
    */
    public function hasStore(): bool
    {
        return $this->store()->exists();
    }

    public function hasPublicStore(): bool
    {
        return $this->publicStore()->exists();
    }

    /*
    |--------------------------------------------------------------------------
    | Query Scopes (API)
    |--------------------------------------------------------------------------
    */
    public function scopeIncluded(Builder $query): Builder
    {
        $relations = array_filter(
            explode(',', request('included', '')),
            fn ($relation) => in_array($relation, $this->allowIncluded)
        );

        return empty($relations) ? $query : $query->with($relations);
    }

    public function scopeFilter(Builder $query): Builder
    {
        foreach (request('filter', []) as $field => $value) {
            if (in_array($field, $this->allowFilter)) {
                $query->where($field, 'LIKE', "%{$value}%");
            }
        }

        return $query;
    }

    public function scopeGetOrPaginate(Builder $query)
    {
        $perPage = (int) request('perPage');

        return $perPage > 0
            ? $query->paginate($perPage)
            : $query->get();
    }
}
