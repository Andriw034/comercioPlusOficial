<?php

return [
    'cloud_name' => env('CLOUDINARY_CLOUD_NAME', ''),
    'api_key' => env('CLOUDINARY_API_KEY', ''),
    'api_secret' => env('CLOUDINARY_API_SECRET', ''),
    'url' => env('CLOUDINARY_URL', ''),
    'timeout' => (int) env('CLOUDINARY_TIMEOUT', 45),
];

