﻿<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // Archived in database/migrations_archive/fase4b_20260206 (Phase 4B gate)
    }

    public function down(): void
    {
        // no-op
    }
};
